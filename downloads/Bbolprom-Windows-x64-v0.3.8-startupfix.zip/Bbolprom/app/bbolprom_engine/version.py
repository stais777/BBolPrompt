VERSION = '0.3.8-startupfix'
