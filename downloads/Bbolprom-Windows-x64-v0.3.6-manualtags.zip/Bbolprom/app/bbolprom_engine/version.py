VERSION = '0.3.6-manualtags'
